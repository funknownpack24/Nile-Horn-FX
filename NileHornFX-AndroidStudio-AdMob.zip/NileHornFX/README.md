# NileHorn FX — Offline-First Currency Exchange & Customer Credit Android App

Complete Android Studio WebView project with native Google AdMob integration.

## AdMob Configuration
- **Application ID**: `ca-app-pub-1576105176117641~6711461467` (configured in `app/src/main/AndroidManifest.xml`)
- **Banner Ad Unit ID**: `ca-app-pub-1576105176117641/7459894363` (configured in `MainActivity.kt`)

## How to Build the APK via GitHub Actions (No Local Android Studio Required)
1. Extract `NileHornFX-AndroidStudio-AdMob.zip`.
2. Create a new repository on GitHub and upload the contents of the `NileHornFX/` folder (including the hidden `.github/workflows/build-apk.yml` file).
3. Open the **Actions** tab in your GitHub repository — the workflow automatically compiles both **NileHornFX-Debug-APK** and **NileHornFX-Release-APK** and attaches them under **Artifacts**.

## How to Build Locally in Android Studio
1. Open Android Studio (Ladybug / Meerkat or newer) and select **Open** → choose the `NileHornFX` folder.
2. Wait for Gradle sync to finish.
3. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)** to generate your installable APK.
4. For Google Play Store distribution, generate a private keystore via **Build → Generate Signed Bundle / APK** and update `signingConfig` in `app/build.gradle.kts`.
