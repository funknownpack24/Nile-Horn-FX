# Preserve JavaScript bridge methods for WebView + AdMob
-keepclassmembers class com.nilehorn.fx.MainActivity$AdMobWebBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
