package com.nilehorn.fx

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {

    companion object {
        private const val BANNER_AD_UNIT_ID = "ca-app-pub-1576105176117641/7459894363"
    }

    private lateinit var webView: WebView
    private lateinit var adBannerContainer: FrameLayout
    private var adView: AdView? = null
    private var isAdMobInitialized = false
    private var isBannerLoaded = false

    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        adBannerContainer = findViewById(R.id.adBannerContainer)

        setupOfflineFirstWebView()
        setupBackNavigation()
        registerConnectivityObserver()

        MobileAds.initialize(this) {
            isAdMobInitialized = true
            if (isNetworkAvailable()) {
                loadAdaptiveBannerAd()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupOfflineFirstWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
        }

        webView.addJavascriptInterface(AdMobWebBridge(), "AndroidAdMob")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                return !(url.startsWith("file:///android_asset/") || url.startsWith("blob:") || url.startsWith("data:"))
            }
        }

        webView.loadUrl("file:///android_asset/nilehorn-fx.html")
    }

    private fun loadAdaptiveBannerAd() {
        if (!isAdMobInitialized || !isNetworkAvailable()) return

        if (adView == null) {
            val banner = AdView(this).apply {
                adUnitId = BANNER_AD_UNIT_ID
                setAdSize(calculateAnchoredAdaptiveAdSize())
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        isBannerLoaded = true
                        adBannerContainer.visibility = View.VISIBLE
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        isBannerLoaded = false
                        adBannerContainer.visibility = View.GONE
                    }
                }
            }
            adBannerContainer.removeAllViews()
            adBannerContainer.addView(banner)
            adView = banner
        }

        adView?.loadAd(AdRequest.Builder().build())
    }

    private fun calculateAnchoredAdaptiveAdSize(): AdSize {
        val displayMetrics = resources.displayMetrics
        val adWidthPixels = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            windowManager.currentWindowMetrics.bounds.width().toFloat()
        } else {
            displayMetrics.widthPixels.toFloat()
        }
        val adWidthDp = (adWidthPixels / displayMetrics.density).toInt().coerceAtLeast(320)
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidthDp)
    }

    private fun registerConnectivityObserver() {
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread {
                    if (!isBannerLoaded) {
                        loadAdaptiveBannerAd()
                    }
                }
            }

            override fun onLost(network: Network) {
                runOnUiThread {
                    if (!isNetworkAvailable() && !isBannerLoaded) {
                        adBannerContainer.visibility = View.GONE
                    }
                }
            }
        }
        networkCallback = callback
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        connectivityManager.registerNetworkCallback(request, callback)
    }

    private fun isNetworkAvailable(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    inner class AdMobWebBridge {
        @JavascriptInterface
        fun onNetworkChanged(isOnline: Boolean) {
            runOnUiThread {
                if (isOnline && !isBannerLoaded) {
                    loadAdaptiveBannerAd()
                }
            }
        }
    }

    override fun onPause() {
        adView?.pause()
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        adView?.resume()
    }

    override fun onDestroy() {
        networkCallback?.let { connectivityManager.unregisterNetworkCallback(it) }
        adView?.destroy()
        webView.destroy()
        super.onDestroy()
    }
}
